#!/bin/bash

start=$(date +%Y%m%d%H%M%S)
echo "Start: $start"

cpu_lim=5000
competition=$1
restart_base_fast=$2
restart_base_slow=$3
dir="C:/Users/cball/OneDrive/Documentos/Pessoal/ITA/SAT/Competições/$competition/Benchmark/*.cnf"
echo "Dir: $dir"

versions=(cadical_v21)
for version in ${versions[@]}; do

    echo "Version: $version"
    echo "Restart base fast: $restart_base_fast"
    echo "Restart base slow: $restart_base_slow"

    now=$(date +%Y%m%d%H%M%S)
    csv_file="../output/$version-$restart_base_fast-$restart_base_slow-$competition-$now.csv"
    log_file="../output/$version-$restart_base_fast-$restart_base_slow-$competition-$now.log"

    echo "Now: $now"
    echo "CSV file: $csv_file"
    echo "Log file: $log_file"

    echo -e "ID\tversion\trestart base fast\trestart base slow\tfile\tvars\tclauses\tconflicts\tlearned\tdecisions\tpropagations\trestarts\trestarts unstable\trestarts stable\tlearned avg. size\tlearnt stack avg\tlearnt stack stable counter\tlearnt stack unstable counter\tanswer\tcpu time" >> $csv_file

    counter=1 
    for filename in $dir; do

        echo "File $counter: $filename"
        echo -e -n "$counter\t$version\t$restart_base_fast\t$restart_base_slow\t$filename\t" >> $csv_file
	    ../build/cadical -n -q --restartbasefast=$restart_base_fast --restartbaseslow=$restart_base_slow -t $cpu_lim $filename >> $csv_file 2>> $log_file
        counter=$((counter+1))

    done

    echo -e "\n"

done

finish=$(date +%Y%m%d%H%M%S)
echo "Finish: $finish"